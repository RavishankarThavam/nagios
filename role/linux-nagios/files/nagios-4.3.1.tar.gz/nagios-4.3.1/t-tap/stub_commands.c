/* Stub file for routines from commands.c */

int close_command_file(void) { return OK; }
